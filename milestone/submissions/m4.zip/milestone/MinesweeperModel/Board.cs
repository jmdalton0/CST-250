﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MinesweeperModel
{
    public class Board
    {
        // no set for size because once initialized, the underlying 2D array cannot be dynamically resized
        public int size { get; }
        public int difficulty { get; set; }
        private Cell[,] grid;

        // constructor
        public Board(int size, int difficulty)
        {
            this.size = size;
            this.difficulty = difficulty;
            this.grid = new Cell[size, size];
        }

        // index a cell
        public Cell at(int row, int col)
        {
            if (
                row < 0 ||
                row > size - 1 ||
                col < 0 ||
                col > size - 1
            )
            {
                return null;
            }
            return grid[row, col];
        }

        // populate the board with live cells
        public void setupLiveNeighbors()
        {
            for (int i = 0; i < size; i++)
            {
                for (int j = 0; j < size; j++)
                {
                    // init new Cell and set row and col, then add to grid
                    Cell cell = new Cell();
                    cell.row = i;
                    cell.col = j;
                    grid[i, j] = cell;
                }
            }

            // total number of cells times percentage of mines
            int numLiveCells = size * size * difficulty / 100;

            Random rand = new Random();
            // until all mines have been placed at random locations
            while (numLiveCells > 0)
            {
                int rRow = rand.Next(size);
                int rCol = rand.Next(size);
                // if the randomly selected cell is not already live
                if (!grid[rRow, rCol].live)
                {
                    grid[rRow, rCol].live = true;
                    numLiveCells--;
                }
            }
        }

        // populate each cells numLiveNeighbors attribute
        public void calculateLiveNeighbors()
        {
            // for each live cell
            for (int i = 0; i < size; i++)
            {
                for (int j = 0; j < size; j++)
                {
                    if (grid[i, j].live)
                    {
                        // for each surrounding cell (only valid array indeces)
                        int prevRow = i > 0 ? -1 : 0;
                        int prevCol = j > 0 ? -1 : 0;
                        int nextRow = i < size - 1 ? 1 : 0;
                        int nextCol = j < size - 1 ? 1 : 0;
                        for (int u = prevRow; u <= nextRow; u++)
                        {
                            for (int v = prevCol; v <= nextCol; v++)
                            {
                                // add 1 live neighbor
                                grid[i + u, j + v].numLiveNeighbors++;
                            }
                        }
                    }
                }
            }
        }

        // check if all dead cells have been cleared
        public bool cleared()
        {
            // for each cell
            for (int i = 0; i < size; i++)
            {
                for (int j = 0; j < size; j++)
                {
                    // if the cell is dead and not yet visited return false
                    Cell cur = grid[i, j];
                    if (!cur.live && !cur.visited)
                    {
                        return false;
                    }
                }
            }
            // if all dead cells have been visited return true
            return true;
        }
    }
}
