﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MinesweeperGUI
{
    public partial class gameForm : Form
    {
        private const int BTN_SIZE = 30;

        private int size;
        private Button[,] grid;

        public gameForm(Level level)
        {
            InitializeComponent();
            size = level == Level.easy ? 16 : level == Level.medium ? 24 : 32;
            grid = new Button[size, size];
            init();
        }

        private void init()
        {
            for (int i = 0; i < size; i++)
            {
                for (int j = 0; j < size; j++)
                {
                    Button button = new Button();
                    button.Width = BTN_SIZE;
                    button.Height = BTN_SIZE;
                    button.Click += button_Click;
                    button.Location = new Point(BTN_SIZE * i, BTN_SIZE * j);
                    button.Tag = i.ToString() + "|" + j.ToString();
                    this.Controls.Add(button);
                }
            }
        }

        private void button_Click(object sender, EventArgs e)
        {
            Button button = (Button)sender;
            button.Text = button.Tag.ToString().Split('|')[0];
        }
    }
}
