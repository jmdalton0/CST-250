﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MinesweeperGUI
{

    public enum Level
    {
        easy = 0,
        medium = 1,
        difficult = 2,
    }

    public partial class MenuForm : Form
    {
        public MenuForm()
        {
            InitializeComponent();
        }

        private void playButton_Click(object sender, EventArgs e)
        {
            Level level = Level.easy;
            if (easyRadio.Checked)
            {
                level = Level.easy;
            }
            else if (mediumRadio.Checked)
            {
                level = Level.medium;
            }
            else
            {
                level = Level.difficult;
            }

            gameForm form = new gameForm(level);
            form.ShowDialog();
        }
    }
}
