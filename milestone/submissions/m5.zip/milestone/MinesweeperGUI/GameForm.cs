﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using MinesweeperModel;

namespace MinesweeperGUI
{
    public partial class gameForm : Form
    {
        private const int BTN_SIZE = 30;

        private Controller controller;
        private Button[,] grid;
        private Stopwatch stopwatch;

        public gameForm(Level level)
        {
            InitializeComponent();
            controller = new Controller(level);
            int size = controller.getSize();
            grid = new Button[size, size];
            stopwatch = new Stopwatch();
            stopwatch.Start();
            init();
        }

        private void init()
        {
            int size = controller.getSize();
            for (int i = 0; i < size; i++)
            {
                for (int j = 0; j < size; j++)
                {
                    Button button = new Button();
                    button.Width = BTN_SIZE;
                    button.Height = BTN_SIZE;
                    button.MouseDown += button_MouseDown;
                    button.Location = new Point(BTN_SIZE * j, BTN_SIZE * i);
                    button.Tag = ((size * i) + j).ToString();
                    this.Controls.Add(button);
                    grid[i, j] = button;
                }
            }
        }

        private void show(int row, int col, bool flag)
        {
            if (controller.isLive(row, col))
            {
                if (flag)
                {
                    grid[row, col].BackColor = Color.Teal;
                }
                else
                {
                    grid[row, col].BackColor = Color.Red;
                }
            }
            else
            {
                grid[row, col].BackColor = Color.Gainsboro;
                int numLiveNeighbors = controller.getNumLiveNeighborsAt(row, col);
                if (numLiveNeighbors > 0)
                {
                    grid[row, col].Text = numLiveNeighbors.ToString();
                }
            }
        }

        private void end(bool win)
        {
            int size = controller.getSize();
            for (int i = 0; i < size; i++)
            {
                for (int j = 0; j < size; j++)
                {
                    show(i, j, win);
                }
            }
            if (win)
            {
                stopwatch.Stop();
                MessageBox.Show("YOU WIN\nTime: " + stopwatch.Elapsed.ToString("mm\\:ss"));
            }
            else {
                MessageBox.Show("GAME OVER");
            }
        }

        private void button_MouseDown(object sender, MouseEventArgs e)
        {
            Button button = (Button)sender;
            int size = controller.getSize();
            int tag = int.Parse(button.Tag.ToString());
            int row = tag / size;
            int col = tag % size;
            
            if (controller.isVisited(row, col))
            {
                return;
            }
            else if (e.Button == MouseButtons.Left)
            {
                if (controller.isLive(row, col))
                {
                    end(false);
                }
 
                List<Tuple<int, int>> visited = new List<Tuple<int, int>> ();
                controller.floodFill(row, col, visited);

                foreach (Tuple<int, int> coord in visited)
                {
                    show(coord.Item1, coord.Item2, false);
                }
            }
            else
            {
                if (button.BackColor == Color.Silver)
                {
                    button.BackColor = Color.White;
                } else
                {
                    button.BackColor = Color.Silver;
                }
            }

            if (controller.cleared())
            {
                end(true);
            }
        }

    }
}
