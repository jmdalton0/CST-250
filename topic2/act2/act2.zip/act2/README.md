# Jesse Dalton
## CST 250
## Activity 2

Screencast of demonstration of Animal Classes part of activity 2:
[video](https://www.loom.com/share/4a6b5c799d8b4b57ba612ae977c8d4e5)

